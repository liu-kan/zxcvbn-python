import threading

# Global configuration for thread safety
_THREAD_SAFE = False
_lock = threading.Lock()
